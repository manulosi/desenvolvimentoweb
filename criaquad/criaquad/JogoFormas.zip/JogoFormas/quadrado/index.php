<!DOCTYPE html>
<html lang="en">
<?php
include_once('quadrado.php');
?>

<head>


    <title>Formulário de criação de formas</title>
</head>

<body>

    

        <a class="nav-link active" aria-current="page" href="#">Cadastro de Quadrado</a>
        <a class="nav-link" href="../unidade/index.php">Cadastro de Unidade</a>


        <form action="quadrado.php" method="post">

                    <h4> <b>Cadastro de Quadrado</b></h4>



                    <label class="form-label" for="altura">Altura</label>
                    <input type="number" class="form-control" name="altura" id="altura" value="<?= $id ? $quadrado->getAltura() : 0 ?>" placeholder=" Digite a altura de sua forma">

                    <label class="form-label" for="cor">Cor</label>
                    <input type="color" class="form-control form-control-color" name="cor" id="cor" placeholder=" Digite a cor de sua forma" value="<?= $id ? $quadrado->getCor() : "black" ?>">


                    <label class="form-label" for="unidade">Unidade</label>
                    <select class="form-select" name="unidade" id="unidade">
                        <?php
                        $unidades = Unidade::listar();
                        foreach ($unidades as $unidade) {
                            echo " <option value=" . $unidade->getId()  . "> " . $unidade->getUnidade() . " </option>";
                        }
                        ?>
                    </select>





            <input type="text" name="id" id="id" value="<?= isset($quadrado) ? $quadrado->getId() : 0 ?>" placeholder=" Digite a unidade de sua forma" hidden>

                    <input type="submit" name="acao" id="acao" value="Salvar">
                    <input type="reset" name="resetar" id="resetar" value="Resetar">

        </form>

        <form action="" method="get">

                    <h4><b>Busca</b></h4>


                    <input type="text" class="form-control" name="busca" id="busca" placeholder="Busca">

                    <select class="form-select" name="tipo" id="tipo">
                        <option value="1">ID</option>
                        <option value="2">Lado</option>
                        <option value="3">Cor</option>
                        <option value="4">Unidade</option>
                    </select>

                    <input type="submit" name="acao" id="acao" value="Buscar">


        </form>
        <table class="table table-striped mt-5" border="1px">
            <thead class="table-dark">
                <th>Id</th>
                <th>Altura</th>
                <th>Cor</th>
                <th>Unidade</th>
                <th>Quadrados</th>
            </thead>

            <?php
            foreach ($lista as $quadrado) {
                echo "<tr>
                         <td>". $quadrado->getId() . "</td>
                         <td>" . $quadrado->getAltura() . "</td>
                         <td>" . $quadrado->getCor() . "</td>
                         <td>" . $quadrado->getUnidade()->getUnidade()  . "</a></td>";
                echo "<td><a href='index.php?id=" . $quadrado->getId() . "'>" . $quadrado->desenharQuadrado($quadrado) . "</a>
                        </td>";
            }

            ?>
        </table>
</body>

</html>