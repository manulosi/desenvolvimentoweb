<?php
define('USUARIO', 'root');//define usuario
define('SENHA', '');//define senha
define('HOST', 'localhost');//define host
define('PORT', '3306');//define port
define('DB', 'formageometria');//define schema
define('DSN', 'mysql:host=' . HOST . ';port=' . PORT . ';dbname=' . DB . ';charset=UTF8');//define o banco de dados