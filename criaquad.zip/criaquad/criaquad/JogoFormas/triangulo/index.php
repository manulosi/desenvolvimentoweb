<!DOCTYPE html>
<html lang="en">
<?php
    include_once('triangulo.php');
    require_once("../navbar.php");
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Formulário de Criação de Triângulos</title>
</head>

<body class="bg-gray-100">

    <div class="container mx-auto p-6">
        <h1 class="text-3xl font-bold text-center mb-6">Formulário de Criação de Triângulos</h1>

        <form action="triangulo.php" method="post" enctype="multipart/form-data" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <input type="hidden" name="id" id="id" value="<?= $id ? $triangulo->getId() : 0 ?>">

            <!-- Lado 1 -->
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="lado1">Lado 1</label>
                <input type="number" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="lado1" id="lado1" value="<?= $id ? $triangulo->getLado1() : 0 ?>" placeholder="Comprimento do Lado 1" required>
            </div>

            <!-- Lado 2 -->
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="lado2">Lado 2</label>
                <input type="number" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="lado2" id="lado2" value="<?= $id ? $triangulo->getLado2() : 0 ?>" placeholder="Comprimento do Lado 2" required>
            </div>

            <!-- Lado 3 -->
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="lado3">Lado 3</label>
                <input type="number" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="lado3" id="lado3" value="<?= $id ? $triangulo->getLado3() : 0 ?>" placeholder="Comprimento do Lado 3" required>
            </div>

            <!-- Cor -->
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="cor">Cor</label>
                <input type="color" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="cor" id="cor" value="<?= $id ? $triangulo->getCor() : '#000000' ?>">
            </div>

            <!-- Botões de Ação -->
            <div class="flex items-center justify-between space-x-2">
                <button type="submit" name="acao" value="Salvar" class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Salvar</button>
                <button type="submit" name="acao" value="Alterar" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Alterar</button>
                <button type="submit" name="acao" value="Excluir" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Excluir</button>
            </div>
        </form>

        <!-- Tabela de Resultados -->
        <div class="overflow-x-auto">
            <table class="table-auto w-full bg-white shadow-md rounded border-collapse border border-gray-200">
                <thead>
                    <tr class="bg-gray-800 text-white">
                        <th class="px-4 py-2">Id</th>
                        <th class="px-4 py-2">Lado 1</th>
                        <th class="px-4 py-2">Lado 2</th>
                        <th class="px-4 py-2">Lado 3</th>
                        <th class="px-4 py-2">Tipo</th> <!-- Nova coluna para o tipo de triângulo -->
                        <th class="px-4 py-2">Área</th>
                        <th class="px-4 py-2">Perímetro</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Verificar se $lista está definido e não é vazio
                    if (isset($lista) && !empty($lista)) {
                        foreach ($lista as $triangulo) {
                            // Determine o tipo de triângulo
                            $tipo = "";
                            if ($triangulo->getLado1() == $triangulo->getLado2() && $triangulo->getLado2() == $triangulo->getLado3()) {
                                $tipo = "Equilátero";
                            } elseif ($triangulo->getLado1() == $triangulo->getLado2() || $triangulo->getLado2() == $triangulo->getLado3() || $triangulo->getLado1() == $triangulo->getLado3()) {
                                $tipo = "Isósceles";
                            } else {
                                $tipo = "Escaleno";
                            }

                            echo "<tr class='bg-gray-100'>
                                <td class='border px-4 py-2'><a href='triangulo.php?id=" . $triangulo->getId() . "' class='text-blue-500 hover:underline'>" . $triangulo->getId() . "</a></td>
                                <td class='border px-4 py-2'>" . $triangulo->getLado1() . "</td>
                                <td class='border px-4 py-2'>" . $triangulo->getLado2() . "</td>
                                <td class='border px-4 py-2'>" . $triangulo->getLado3() . "</td>
                                <td class='border px-4 py-2'>" . $tipo . "</td> <!-- Exibir tipo aqui -->
                                <td class='border px-4 py-2'>" . number_format($triangulo->calcularArea(), 2) . "</td>
                                <td class='border px-4 py-2'>" . number_format($triangulo->calcularPerimetro(), 2) . "</td>
                            </tr>";
                        }
                    } else {
                        echo "<tr class='bg-gray-200'>
                            <td colspan='7' class='border px-4 py-2 text-center'>Nenhum triângulo encontrado.</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
