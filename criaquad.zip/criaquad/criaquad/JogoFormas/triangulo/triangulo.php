<?php
session_start(); // Iniciar a sessão
require_once("../classes/Triangulo.class.php");
require_once("../classes/Unidade.class.php");
require_once("../classes/Database.class.php");

// Obter ID e mensagem da URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$msg = isset($_GET['MSG']) ? $_GET['MSG'] : "";

// Buscar o triângulo se o ID for maior que 0
$triangulo = null;
if ($id > 0) {
    $triangulo = Triangulo::listar(1, $id)[0] ?? null; // Usar null coalescing para evitar erros
}

// Processar o formulário quando a requisição for POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $lado1 = isset($_POST['lado1']) ? floatval($_POST['lado1']) : 0; // Lado 1 do triângulo
    $lado2 = isset($_POST['lado2']) ? floatval($_POST['lado2']) : 0; // Lado 2 do triângulo
    $lado3 = isset($_POST['lado3']) ? floatval($_POST['lado3']) : 0; // Lado 3 do triângulo
    $cor = isset($_POST['cor']) ? trim($_POST['cor']) : ""; // Cor do triângulo
    $unidade = isset($_POST['unidade']) ? intval($_POST['unidade']) : 0; // Unidade
    $arquivo = $_FILES['fundo'] ?? null; // Imagem de fundo
    $acao = $_POST['acao'] ?? ""; // Ação (Salvar, Alterar, Excluir)
    
    $destino = ""; // Inicializa a variável destino

    try {
        // Buscar a unidade
        $uni = Unidade::listar(1, $unidade);
        if (empty($uni) || !isset($uni[0])) {
            throw new Exception("Unidade não encontrada.");
        }

        // Verifica se o arquivo foi enviado corretamente
        if ($arquivo && $arquivo['error'] == UPLOAD_ERR_OK) {
            $destino = "../" . IMG . "/" . basename($arquivo['name']); // Define o destino da imagem
        }

        // Criar o objeto Triangulo
        $triangulo = new Triangulo($id, $lado1, $lado2, $lado3, $cor, $uni[0], $destino);
        
        // Executar a ação
        switch ($acao) {
            case "Salvar":
                $resultado = $triangulo->incluir();
                break;
            case "Alterar":
                $resultado = $triangulo->alterar();
                break;
            case "Excluir":
                $resultado = $triangulo->excluir();
                break;
            default:
                throw new Exception("Ação inválida.");
        }

        $_SESSION['MSG'] = "Dados inseridos/Alterados com sucesso!";

        // Mover o arquivo apenas se o resultado foi bem-sucedido
        if ($resultado && $destino) {
            move_uploaded_file($arquivo['tmp_name'], $destino); // Mover o arquivo enviado para o destino
        }
        header('Location: index.php'); // Redirecionar para a página de índice
        exit; // Sempre uma boa prática usar exit após header
        
    } catch (Exception $e) {
        // Armazenar mensagem de erro na sessão
        $_SESSION['ERROR'] = $e->getMessage();
        header('Location: index.php'); // Redirecionar para a página de índice
        exit;
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $busca = isset($_GET['busca']) ? trim($_GET['busca']) : ""; // Busca na lista
    $tipo = isset($_GET['tipo']) ? intval($_GET['tipo']) : 0; // Tipo de busca
    $lista = Triangulo::listar($tipo, $busca); // Listar triângulos
}
?>
