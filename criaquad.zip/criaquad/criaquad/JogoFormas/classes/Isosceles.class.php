<?php
require_once("Triangulo.class.php");

class Isosceles extends Triangulo {
    public function __construct($id = 0, $ladoBase = 1, $ladoIgual = 1, $cor = "black", Unidade $unidade = null, $fundo = "null") {
        parent::__construct($id, $ladoBase, $ladoIgual, $ladoIgual, $cor, $unidade, $fundo);
    }

    public function desenhar() {
        // Implementar a lógica para desenhar um triângulo isósceles
    }
}
?>
