<?php
require_once("Triangulo.class.php");

class Escaleno extends Triangulo {
    public function __construct($id = 0, $lado1 = 1, $lado2 = 1, $lado3 = 1, $cor = "black", Unidade $unidade = null, $fundo = "null") {
        parent::__construct($id, $lado1, $lado2, $lado3, $cor, $unidade, $fundo);
    }

    public function desenhar() {
        // Implementar a lógica para desenhar um triângulo escaleno
    }
}
?>
