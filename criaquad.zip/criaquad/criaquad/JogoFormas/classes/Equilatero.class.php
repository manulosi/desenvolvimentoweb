<?php
require_once("Triangulo.class.php");

class Equilatero extends Triangulo {
    public function __construct($id = 0, $lado = 1, $cor = "black", Unidade $unidade = null, $fundo = "null") {
        parent::__construct($id, $lado, $lado, $lado, $cor, $unidade, $fundo);
    }

    public function desenhar() {
        // Implementar a lógica para desenhar um triângulo equilátero
    }
}
?>
