<?php
require_once("../classes/Database.class.php");
require_once("../classes/Unidade.class.php");

class Triangulo {
    private $id;
    private $lado1;
    private $lado2;
    private $lado3;
    private $cor;
    private $unidade; // Correto
    private $imagem;

    public function __construct($id, $lado1, $lado2, $lado3, $cor, $unidade, $imagem = "") {
        $this->id = $id;
        $this->lado1 = $lado1;
        $this->lado2 = $lado2;
        $this->lado3 = $lado3;
        $this->cor = $cor;
        $this->unidade = $unidade; // Correto
        $this->imagem = $imagem;
    }

    public function incluir() {
        $db = Database::getInstance(); 
        try {
            $sql = "INSERT INTO triangulos (lado1, lado2, lado3, cor, unidade_id, fundo) VALUES (:lado1, :lado2, :lado3, :cor, :unidade_id, :fundo)";
            $stmt = $db->prepare($sql);
            $stmt->bindValue(':lado1', $this->lado1);
            $stmt->bindValue(':lado2', $this->lado2);
            $stmt->bindValue(':lado3', $this->lado3);
            $stmt->bindValue(':cor', $this->cor);
            $stmt->bindValue(':unidade_id', $this->unidade->getIdUni()); // Agora deve funcionar
            $stmt->bindValue(':fundo', $this->imagem); // Corrigido para usar a propriedade imagem
            return $stmt->execute(); 
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false; 
        }
    }

    public function alterar() {
        $db = Database::getInstance();
        try {
            $sql = "UPDATE triangulos SET lado1 = :lado1, lado2 = :lado2, lado3 = :lado3, cor = :cor, unidade_id = :unidade_id, fundo = :fundo WHERE id = :id";
            $stmt = $db->prepare($sql);
            $stmt->bindValue(':id', $this->id);
            $stmt->bindValue(':lado1', $this->lado1);
            $stmt->bindValue(':lado2', $this->lado2);
            $stmt->bindValue(':lado3', $this->lado3);
            $stmt->bindValue(':cor', $this->cor);
            $stmt->bindValue(':unidade_id', $this->unidade->getIdUni());
            $stmt->bindValue(':fundo', $this->imagem);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    public function excluir() {
        $db = Database::getInstance();
        try {
            $sql = "DELETE FROM triangulos WHERE id = :id";
            $stmt = $db->prepare($sql);
            $stmt->bindValue(':id', $this->id);
            return $stmt->execute();
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    public static function listar($tipo = 0, $busca = ""): array {
        $db = Database::getInstance();
        $triangulos = [];

        try {
            $sql = "SELECT * FROM triangulos";
            $params = [];

            // Condições de busca
            if ($tipo > 0) {
                $sql .= " WHERE tipo = :tipo";
                $params[':tipo'] = $tipo;
            }

            if (!empty($busca)) {
                $sql .= " AND (lado1 LIKE :busca OR lado2 LIKE :busca OR lado3 LIKE :busca)";
                $params[':busca'] = '%' . $busca . '%';
            }

            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $triangulo = new Triangulo(
                    $row['id'],
                    $row['lado1'],
                    $row['lado2'],
                    $row['lado3'],
                    $row['cor'],
                    new Unidade($row['unidade_id']), // Supondo que você armazena o ID da unidade
                    $row['fundo']
                );
                $triangulos[] = $triangulo;
            }

        } catch (Exception $e) {
            error_log($e->getMessage());
        }

        return $triangulos;
    }

    // Outros métodos permanecem inalterados...

    // Adicione getters e setters se necessário
    public function getUnidade() {
        return $this->unidade; 
    }

    public function getImagem() {
        return $this->imagem; 
    }
}
?>
